#ifndef DATATYPE_H
#define DATATYPE_H
#include <QString>

struct Device
{
    QString IP;
    QString ID;
    int port;
};

#endif // DATATYPE_H
